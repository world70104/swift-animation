//
//  ViewController.swift
//  QRCodeReader
//
//  Created by AlexSong on 2018/8/10.
//  Copyright © 2018 AlexSong. All rights reserved.
//

import UIKit
import SafariServices
import AVFoundation

class ViewController: UIViewController, SFSafariViewControllerDelegate, QRCodeReaderViewControllerDelegate   {
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var qrCodeImg: UIImageView!
    @IBOutlet weak var LearnMoreBtn: UIButton!
    
    var VIEW_SCAN_LINE_TAG = 22222
    
    lazy var reader: QRCodeReader = QRCodeReader()
    lazy var readerVC: QRCodeReaderViewController = {
        let builder = QRCodeReaderViewControllerBuilder {
            $0.reader                  = QRCodeReader(metadataObjectTypes: [.qr], captureDevicePosition: .back)
            $0.showTorchButton         = true
            $0.preferredStatusBarStyle = .lightContent
            
            $0.reader.stopScanningWhenCodeIsFound = false
        }
        
        return QRCodeReaderViewController(builder: builder)
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        scanlineCreate()
        scanlineStart()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    @IBAction func goSite(_ sender: Any) {
        let urlString = "http://www.latitude28produce.com/"
        
        if let url = URL(string: urlString) {
            let vc = SFSafariViewController(url: url)
            vc.delegate = self
            
            present(vc, animated: true)
        }
    }
    
    @IBAction func goQRReader(_ sender: Any) {
        guard checkScanPermissions() else { return }
        
        readerVC.modalPresentationStyle = .formSheet
        readerVC.delegate               = self
        
        readerVC.completionBlock = { (result: QRCodeReaderResult?) in
            if let result = result {
                print("Completion with result: \(result.value) of type \(result.metadataType)")
            }
        }
        
        present(readerVC, animated: true, completion: nil)
    }
    
    // MARK: - Actions
    
    private func checkScanPermissions() -> Bool {
        do {
            return try QRCodeReader.supportsMetadataObjectTypes()
        } catch let error as NSError {
            let alert: UIAlertController
            
            switch error.code {
            case -11852:
                alert = UIAlertController(title: "Error", message: "This app is not authorized to use Back Camera.", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "Setting", style: .default, handler: { (_) in
                    DispatchQueue.main.async {
                        if let settingsURL = URL(string: UIApplicationOpenSettingsURLString) {
                            UIApplication.shared.openURL(settingsURL)
                        }
                    }
                }))
                
                alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            default:
                alert = UIAlertController(title: "Error", message: "Reader not supported by the current device", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            }
            
            present(alert, animated: true, completion: nil)
            
            return false
        }
    }
    
    // MARK: - QRCodeReader Delegate Methods
    
    func reader(_ reader: QRCodeReaderViewController, didScanResult result: QRCodeReaderResult) {
        reader.stopScanning()
        
        dismiss(animated: true) { [weak self] in
            
            let urlString = result.value
            
            if let url = URL(string: urlString) {
                let vc = SFSafariViewController(url: url)
                vc.delegate = self
                
                self?.present(vc, animated: true)
            }
            
/*            let alert = UIAlertController(
                title: "QRCodeReader",
                message: String (format:"%@ (of type %@)", result.value, result.metadataType),
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            
            self?.present(alert, animated: true, completion: nil)*/
        }
    }
    
    func reader(_ reader: QRCodeReaderViewController, didSwitchCamera newCaptureDevice: AVCaptureDeviceInput) {
        print("Switching capturing to: \(newCaptureDevice.device.localizedName)")
    }
    
    func readerDidCancel(_ reader: QRCodeReaderViewController) {
        reader.stopScanning()
        
        dismiss(animated: true, completion: nil)
    }
    
    func scanlineCreate() {
        let scanLineView = UIImageView(frame: CGRect(
            x: containerView.frame.origin.x + 25 + 4,
            y: containerView.frame.origin.y - 20,
            width:qrCodeImg.frame.size.width - 8,
            height:50))
        scanLineView.tag = VIEW_SCAN_LINE_TAG
        scanLineView.contentMode = .scaleToFill
        scanLineView.image = UIImage(named: "scanline.png")
        scanLineView.isHidden = true
        //        scanLineView.frame.origin.y = innerRect.origin.y + 3
        self.view.addSubview(scanLineView)
    }
    
    func scanlineStart() {
        DispatchQueue.main.async {
            let scanLineView = self.view.viewWithTag(self.VIEW_SCAN_LINE_TAG) as! UIImageView
            //            if scanLineView != nil {
            scanLineView.isHidden = false
            //                let frame = UIScreen.main.bounds
            let animation = CABasicAnimation(keyPath: "position" )
            //            animation.toValue = NSValue(cgPoint: CGPoint(x:scanLineView.center.x, y:frame.size.height));
            animation.toValue = NSValue(cgPoint: CGPoint(x:scanLineView.center.x,
                    y:self.qrCodeImg.frame.size.height + self.containerView.frame.origin.y - 4 )) // self.qrCodeImg.frame.origin.y));
            animation.autoreverses = false //  YES;
            animation.duration = 3.0;
            animation.repeatCount = Float.infinity //HUGE_VAL;
            animation.isRemovedOnCompletion = false //NO;
            animation.fillMode = kCAFillModeForwards;
            scanLineView.layer.add(animation, forKey:"position");
            
            //                scanLineView.frame.origin.y = self.innerRect.origin.y + 3
            //            }
        }
    }
    
    func scanlineStop() {
        DispatchQueue.main.async {
            let scanLineView = self.view.viewWithTag(self.VIEW_SCAN_LINE_TAG) as! UIImageView
            //            if let scanLineView = self.viewWithTag(self.VIEW_SCAN_LINE_TAG) as! UIImageView {
            scanLineView.isHidden = true
            scanLineView.layer.removeAllAnimations();
            //            }
        }
    }

}
