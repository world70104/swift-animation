/*
 * QRCodeReader.swift
 *
 * Copyright 2014-present Yannick Loriot.
 * http://yannickloriot.com
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 */

import UIKit

final public class QRCodeReaderView: UIView, QRCodeReaderDisplayable {
    
    let lblNew1 = UILabel(frame:CGRect(x: 0, y: 0, width: 0, height: 0))
    let lblNew2 = UILabel(frame:CGRect(x: 0, y: 0, width: 0, height: 0))
    let lblNew3 = UILabel(frame:CGRect(x: 0, y: 0, width: 0, height: 0))

  public lazy var overlayView: UIView? = {
    let ov = ReaderOverlayView()
    
    let screenSize = UIScreen.main.bounds
//    ov.frame = CGRect(x:0 , y:0, width:screenSize.width, height:screenSize.height)
    ov.backgroundColor                           = .clear // UIColor(red: 0, green: 0, blue: 0, alpha: 0.7)
    ov.clipsToBounds                             = true
    ov.translatesAutoresizingMaskIntoConstraints = false

    return ov
  }()

  public let cameraView: UIView = {
    let cv = UIView()
    cv.clipsToBounds                             = true
    cv.translatesAutoresizingMaskIntoConstraints = false

    return cv
  }()

  public lazy var cancelButton: UIButton? = {
    let cb = UIButton()
    
    cb.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
//    cb.center = view.center
//    cb.addTarget(self, action: #selector(btnPressed), for: UIControlEvents.touchUpInside)
    
    //Border
    cb.layer.borderColor = UIColor.blue.cgColor
//    cb.layer.borderWidth = borderSize
    cb.layer.cornerRadius = 20
/*
    //Image
    let myImage = UIImage(named: "light.png")
    cb.setImage(myImage, for: UIControlState.normal)
    cb.setImage(UIImage(named: "light.png"), for: UIControlState.highlighted)
    cb.imageEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 50, right: 50)
    
    //Text
    cb.setTitle("Telephone", for: UIControlState.normal)
    cb.setTitleColor(UIColor.blue, for: UIControlState.normal)
    cb.setTitleColor(UIColor.white, for: UIControlState.highlighted)
    cb.titleEdgeInsets = UIEdgeInsets(top: 10, left: -myImage!.size.width, bottom: 15, right: 0.0)
*/
    cb.translatesAutoresizingMaskIntoConstraints = false
    cb.setTitleColor(.gray, for: .highlighted)

    return cb
  }()

  public lazy var switchCameraButton: UIButton? = {
    let scb = UIButton(frame: CGRect(x: 200, y: 480, width: 100, height: 100))

    let image = UIImage(named: "icon_back.png")
    scb.set(image: image, title: "BACK", titlePosition: .bottom, additionalSpacing: 0.0, state: .normal)

//    scb.backgroundColor = .green
    return scb
  }()

  public lazy var toggleTorchButton: UIButton? = {
    let ttb = UIButton(frame: CGRect(x: 50, y: 480, width: 100, height: 100))
    let image = UIImage(named: "icon_light.png")
    ttb.set(image: image, title: "LIGHT", titlePosition: .bottom, additionalSpacing: 0.0, state: .normal)

//    ttb.backgroundColor = .green
    return ttb
  }()

  private weak var reader: QRCodeReader?

  public func setupComponents(showCancelButton: Bool, showSwitchCameraButton: Bool, showTorchButton: Bool, showOverlayView: Bool, reader: QRCodeReader?) {
    self.reader               = reader
    reader?.lifeCycleDelegate = self

    addComponents()

    cancelButton?.isHidden       = !showCancelButton
    switchCameraButton?.isHidden = !showSwitchCameraButton
    toggleTorchButton?.isHidden  = !showTorchButton
    overlayView?.isHidden        = !showOverlayView

    guard let cb = cancelButton, let scb = switchCameraButton, let ttb = toggleTorchButton, let ov = overlayView else { return }

    let views = ["cv": cameraView, "ov": ov, "cb": cb, "scb": scb, "ttb": ttb]

    addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[cv]|", options: [], metrics: nil, views: views))
/*
    if showCancelButton {
      addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[cv][cb(40)]|", options: [], metrics: nil, views: views))
      addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-[cb]-|", options: [], metrics: nil, views: views))
    }
    else {
      addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[cv]|", options: [], metrics: nil, views: views))
    }
*/
    addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[cv]|", options: [], metrics: nil, views: views))
/*
    if showSwitchCameraButton {
      addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-[scb(50)]", options: [], metrics: nil, views: views))
      addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[scb(70)]|", options: [], metrics: nil, views: views))
    }
*/
    if showTorchButton {
      addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-[ttb(50)]", options: [], metrics: nil, views: views))
      addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[ttb(70)]", options: [], metrics: nil, views: views))
    }

    for attribute in Array<NSLayoutAttribute>([.left, .top, .right, .bottom]) {
      addConstraint(NSLayoutConstraint(item: ov, attribute: attribute, relatedBy: .equal, toItem: cameraView, attribute: attribute, multiplier: 1, constant: 0))
    }
  }

    override public func draw(_ rect: CGRect) {
//        let fillColor     = UIColor(red: 1, green: 0, blue: 0, alpha: 1.0)
//        fillColor.setFill()
//        UIRectFill(CGRect(x:0,y:0,width:100,height:100))
    }
    
  public override func layoutSubviews() {
    super.layoutSubviews()

    reader?.previewLayer.frame = bounds
    
    super.layoutSubviews()
    let between:CGFloat = 5.0
    // Bounding box setting
    var messageLabelSize = lblNew1.sizeThatFits(CGSize(width: 160.0 - 20.0 * 2.0,
            height: Double(Float.greatestFiniteMagnitude)))
    lblNew1.frame.size.width = messageLabelSize.width
    lblNew1.frame.size.height = messageLabelSize.height
    // Massage setting
    lblNew1.frame.origin.x =
        (self.frame.size.width - lblNew1.frame.size.width) / 2.0
    let screenSize = UIScreen.main.bounds
    let imageHigh = screenSize.width/5
    lblNew1.frame.origin.y = imageHigh + between

    messageLabelSize = lblNew2.sizeThatFits(CGSize(width: 160.0 - 20.0 * 2.0,
        height: Double(Float.greatestFiniteMagnitude)))
    lblNew2.frame.size.width = messageLabelSize.width
    lblNew2.frame.size.height = messageLabelSize.height
    // Massage setting
    lblNew2.frame.origin.x =
        (self.frame.size.width - lblNew2.frame.size.width) / 2.0
    lblNew2.frame.origin.y = imageHigh + between + lblNew2.frame.height + between * 2


    messageLabelSize = lblNew3.sizeThatFits(CGSize(width: 160.0 - 20.0 * 2.0,
                                                   height: Double(Float.greatestFiniteMagnitude)))
    lblNew3.frame.size.width = messageLabelSize.width
    lblNew3.frame.size.height = messageLabelSize.height
    // Massage setting
    lblNew3.frame.origin.x =
        (self.frame.size.width - lblNew3.frame.size.width) / 2.0
    
    var innerRect = screenSize.insetBy(dx: 50, dy: 50)
    let minSize   = min(innerRect.width, innerRect.height)
    if innerRect.width != minSize {
        innerRect.origin.x   += (innerRect.width - minSize) / 2
        innerRect.size.width = minSize
    }
    else if innerRect.height != minSize {
        innerRect.origin.y    += (innerRect.height - minSize) / 2
        innerRect.size.height = minSize
    }

    lblNew3.frame.origin.y = innerRect.origin.y + innerRect.size.height + between * 4
    
    let bottomLbl = lblNew3.frame.origin.y + lblNew3.frame.size.height
    let btnY = bottomLbl + ( screenSize.height - bottomLbl - (switchCameraButton?.frame.size.height)! ) / 2
    let btnXBetween = ( screenSize.width - (switchCameraButton?.frame.size.width)! * 2 ) / 3
    toggleTorchButton?.frame.origin.x = btnXBetween
    toggleTorchButton?.frame.origin.y = btnY

    switchCameraButton?.frame.origin.x = (switchCameraButton?.frame.width)! + 2 * btnXBetween
    switchCameraButton?.frame.origin.y = btnY

  }

  // MARK: - Scan Result Indication

  func startTimerForBorderReset() {
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + .seconds(1)) {
      if let ovl = self.overlayView as? ReaderOverlayView {
        ovl.overlayColor = .white
      }
    }
  }

  func addRedBorder() {
    self.startTimerForBorderReset()

    if let ovl = self.overlayView as? ReaderOverlayView {
      ovl.overlayColor = .red
    }
  }

  func addGreenBorder() {
    self.startTimerForBorderReset()
    
    if let ovl = self.overlayView as? ReaderOverlayView {
      ovl.overlayColor = .green
    }
  }

  @objc public func setNeedsUpdateOrientation() {
    setNeedsDisplay()

    overlayView?.setNeedsDisplay()

    if let connection = reader?.previewLayer.connection, connection.isVideoOrientationSupported {
      let application                    = UIApplication.shared
      let orientation                    = UIDevice.current.orientation
      let supportedInterfaceOrientations = application.supportedInterfaceOrientations(for: application.keyWindow)

      connection.videoOrientation = QRCodeReader.videoOrientation(deviceOrientation: orientation, withSupportedOrientations: supportedInterfaceOrientations, fallbackOrientation: connection.videoOrientation)
    }
  }

  // MARK: - Convenience Methods

  private func addComponents() {
    NotificationCenter.default.addObserver(self, selector: #selector(self.setNeedsUpdateOrientation), name: .UIDeviceOrientationDidChange, object: nil)
    
    addSubview(cameraView)

    if let ov = overlayView {
      addSubview(ov)
    }

    
    let screenSize = UIScreen.main.bounds
    var innerRect = screenSize.insetBy(dx: 50, dy: 50)
    let minSize   = min(innerRect.width, innerRect.height)
    if innerRect.width != minSize {
        innerRect.origin.x   += (innerRect.width - minSize) / 2
        innerRect.size.width = minSize
    }
    else if innerRect.height != minSize {
        innerRect.origin.y    += (innerRect.height - minSize) / 2
        innerRect.size.height = minSize
    }
    
    let topView = UIView(frame: CGRect(x:0,y:0,width:screenSize.size.width,height:innerRect.origin.y-1) )
    topView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.7)
    addSubview(topView)
    let bottomView = UIView(frame: CGRect(x:0,
                                          y:innerRect.origin.y + innerRect.size.height,
                                          width:screenSize.size.width,
                                          height:innerRect.origin.y) )
    bottomView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.7)
    addSubview(bottomView)
    
    let leftView = UIView(frame: CGRect(x:0,
                                        y:innerRect.origin.y - 1,
                                        width:innerRect.origin.x-1,
                                        height:innerRect.size.height + 1) )
    leftView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.7)
    addSubview(leftView)
    
    let righttView = UIView(frame: CGRect(x:innerRect.origin.x + innerRect.size.width,
                                          y:innerRect.origin.y - 1,
                                          width:innerRect.origin.x,
                                          height:innerRect.size.height + 1) )
    righttView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.7)
    addSubview(righttView)

    
    if let scb = switchCameraButton {
      addSubview(scb)
    }

    if let ttb = toggleTorchButton {
      addSubview(ttb)
    }
/*
    if let cb = cancelButton {
      addSubview(cb)
    }
*/
    if let reader = reader {
      cameraView.layer.insertSublayer(reader.previewLayer, at: 0)
      
      setNeedsUpdateOrientation()
    }

    let image = UIImage(named: "logo")
    let newImage = resizeImage(image: image!, newWidth: screenSize.width/5)
    let imageView = UIImageView(image: newImage)
    let imgX = (screenSize.width * 2 )/5
    imageView.frame = CGRect(
        x: imgX, y: 0,
        width: newImage.size.width, height: newImage.size.height)
    addSubview(imageView)

    lblNew1.textAlignment = .center
    lblNew1.text = "BLOCKCHAIN VERIFICATION"
    lblNew1.textColor = UIColor.white
    lblNew1.translatesAutoresizingMaskIntoConstraints = false
    lblNew1.font=UIFont.systemFont(ofSize: 22)
    lblNew1.center = CGPoint(x: screenSize.width/2, y: newImage.size.height + 1)
    addSubview(lblNew1)

    lblNew2.textAlignment = .center
    lblNew2.text = "PLEASE SCAN"
    lblNew2.textColor = UIColor.white
    lblNew2.translatesAutoresizingMaskIntoConstraints = false
    lblNew2.font=UIFont.systemFont(ofSize: 22)
    lblNew2.center = CGPoint(x: screenSize.width/2, y: newImage.size.height + 1)
    addSubview(lblNew2)

    lblNew3.textAlignment = .center
    lblNew3.text = "PUT THE QR CODE IN THE SQUARE AND WAIT"
    lblNew3.textColor = UIColor.white
    lblNew3.translatesAutoresizingMaskIntoConstraints = false
    lblNew3.font=UIFont.systemFont(ofSize: 14)
    lblNew3.center = CGPoint(x: screenSize.width/2, y: newImage.size.height + 1)
    addSubview(lblNew3)

    }
}

func resizeImage(image: UIImage, newWidth: CGFloat) -> UIImage {
    
    let scale = newWidth / image.size.width
    let newHeight = image.size.height * scale
    UIGraphicsBeginImageContext(CGSize(width: newWidth, height: newHeight))
    image.draw(in: CGRect(x:0, y:0, width:newWidth, height: newHeight))
    let newImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    
    return newImage!
}

extension QRCodeReaderView: QRCodeReaderLifeCycleDelegate {
  func readerDidStartScanning() {
    setNeedsUpdateOrientation()
  }

  func readerDidStopScanning() {}
}
